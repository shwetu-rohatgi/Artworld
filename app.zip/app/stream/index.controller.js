﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('Stream.IndexController', Controller);

    function Controller(UserService,FlashService,PhantService) {
        
        var vm = this;
      
        vm.isRegisteredDevice = isRegisteredDevice;
        vm.checkDeviceId=checkDeviceId;
        vm.UpdateRegisterDevice=UpdateRegisterDevice;
        vm.registerDevice=registerDevice;
        
        vm.user = null;
        vm.device = {};

        initController();


        function initController() {


            vm.device.found = false;
            vm.isedit = false;
            vm.isSuccess = false;

            // get current user
            UserService.GetCurrent().then(function (user){
                vm.user = user;
            });

        
           var serial  = getParameterByName('serial');

           if(serial != null)
           {
               vm.isedit = true;

               UserService.GetDeviceRegistrationData(serial).then(function (device) {

                    vm.device=device;
                    vm.device.found = true;
                   
              });
            
            }

            console.log( vm.isedit);
            
        }

        function registerDevice() {
            
            PhantService.Create(vm.device).then(function(streamData) 
            {

                vm.device.stream = streamData;
                vm.device.userId = vm.user._id;

                // success now link this id with user id 
                UserService.registerDevice(vm.device).then(function() {
                    $('html,body').scrollTop(0);
                    vm.isSuccess = true;
                }).catch(function (error) {
                    FlashService.Error(error);
                });
            
            }).catch(function (error) {
                    FlashService.Error(error);
            });      

        }

         function UpdateRegisterDevice() {

        // success now link this id with user id 
            UserService.UpdateRegisterDevice(vm.device).then(function() {
                FlashService.Success("Device updated successfully");
            }).catch(function (error) {
                FlashService.Error(error);
            });    

        }

        function isRegisteredDevice(){

            FlashService.LoaderStatus(true);

            UserService.isRegisteredDevice(vm.device.serialNo).then(function(userId) {

             
              if(!userId)
              {
                checkDeviceId();
              }
              else
              {
              
                FlashService.LoaderStatus(false);


                if(userId==vm.user._id){
                    FlashService.Error("You have already registered this device ");
                }
                else{
                    FlashService.Error("This device has already been registered.Please contact support");
                }
                    
              }

            }).catch(function (error) {
                FlashService.Error(error);
            });
          
        }

        function checkDeviceId()
        {

            UserService.CheckDeviceId(vm.device.serialNo).then(function(device) 
            {
            
               FlashService.LoaderStatus(false);

               if(device)
               {
                vm.device.serialNo = device.serialNo;
                vm.device.type = device.type;
                vm.device.found = true;
               }
               else {
                vm.device.found = false;
               }

            })
            .catch(function (error) {
                vm.device.found = false;
                FlashService.Error("Sorry, please verify your serial number, serial number is not found in our database.");
            });    

        }


        function getParameterByName(name, url) 
        {
            if (!url) url = window.location.href;

            name = name.replace(/[\[\]]/g, "\\$&");
            
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            
            results = regex.exec(url);
            
            if (!results) return null;
            
            if (!results[2]) return '';
            
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        
        }


    }

   

})();