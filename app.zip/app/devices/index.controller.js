﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('Devices.IndexController', Controller);

    function Controller(UserService) {

        var vm = this;

        vm.user = null;
        vm.devices = null;

        initController();

        function initController() {
            // get current user
            UserService.GetCurrent().then(function (user) {
                vm.user = user;
               getUserDevices();                
            });
        }


        function getUserDevices()
        {
        
         UserService.GetDevices(vm.user._id).then(function(devices){
                
                console.log(devices);
                if(devices && devices.length>0)
                vm.devices = devices;
            });
    
        }

    }

})();