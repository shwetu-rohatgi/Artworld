﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('PhantService', Service);

    function Service($http, $q) {
        var service = {};

        service.Create = Create;

        return service;

        function Create(stream) {
            return $http.post('/api/phant/create', stream).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
