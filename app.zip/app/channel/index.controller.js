(function () {
    'use strict';

    angular
        .module('app')
        .controller('Channel.IndexController', Controller);

    function Controller(UserService) {
       
        var vm = this;
        vm.user = null;
        initController();

        function initController() {

            console.log("Channel");
            
            // get current user
           UserService.GetCurrent().then(function (user) {
                vm.user = user;
            });
    }
    }

})();