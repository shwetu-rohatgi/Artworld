﻿(function () {
    'use strict';

    angular
    .module('app')
    .controller('Data.IndexController', Controller);

    function Controller(UserService) {

        var vm = this;
        vm.user = null;
        vm.stream = null;

        initController();

        function initController() {

            var streamId = getParameterByName('stream'); 
            var field = getParameterByName('field'); 
            var page = getParameterByName('page'); 

            UserService.GetCurrent().then(function (user) {
                vm.user = user;
            });

            if(streamId && field)
            {
                UserService.GetStreamData(streamId).then(function (streamData) {
                    makeplot(streamData.publicKey, field, page );   
                });                

            }

        }

        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

}

})();